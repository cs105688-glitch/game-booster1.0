package com.charles.gamebooster

import android.annotation.SuppressLint
import android.app.ActivityManager
import android.app.NotificationManager
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.StatFs
import android.provider.Settings
import android.view.View
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView

    // Mapeia codinomes de hardware comuns para nomes comerciais conhecidos.
    // Cobre os chipsets mais usados em aparelhos de entrada/médio no Brasil;
    // fora dessa lista, cai no codinome bruto do Android (ainda real, só menos "amigável").
    private val CHIPSET_NAMES = mapOf(
        "qcom" to "Qualcomm Snapdragon",
        "mt6789" to "MediaTek Helio G99",
        "mt6785" to "MediaTek Helio G95",
        "mt6768" to "MediaTek Helio G85",
        "mt6853" to "MediaTek Dimensity 720",
        "mt6833" to "MediaTek Dimensity 700",
        "mt6877" to "MediaTek Dimensity 900",
        "exynos850" to "Samsung Exynos 850",
        "exynos1280" to "Samsung Exynos 1280",
        "sm6225" to "Qualcomm Snapdragon 680",
        "sm6115" to "Qualcomm Snapdragon 662",
        "sdm660" to "Qualcomm Snapdragon 660",
        "unisoc" to "Unisoc Tiger"
    )

    // Ponte JS <-> Android: exposta ao HTML como "AndroidBridge"
    inner class WebAppInterface {
        @JavascriptInterface
        fun getDeviceSpecs(): String {
            val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
            val mi = ActivityManager.MemoryInfo()
            am.getMemoryInfo(mi)
            val ramGb = Math.round(mi.totalMem / 1_073_741_824.0)

            val stat = StatFs(filesDir.path)
            val storageGb = Math.round(stat.totalBytes / 1_073_741_824.0)
            val storageFreeGb = Math.round(stat.availableBytes / 1_073_741_824.0)

            // Build.SOC_MODEL (API 31+) costuma trazer o nome real do SoC em aparelhos recentes;
            // em aparelhos mais antigos ou sem suporte, usa o codinome de HARDWARE mapeado acima.
            val socRaw = if (Build.VERSION.SDK_INT >= 31 && Build.SOC_MODEL != Build.UNKNOWN) {
                Build.SOC_MODEL
            } else {
                Build.HARDWARE
            }
            val chipset = CHIPSET_NAMES[socRaw.lowercase()] ?: socRaw

            val json = JSONObject()
            json.put("manufacturer", Build.MANUFACTURER)
            json.put("model", Build.MODEL)
            json.put("chipset", chipset)
            json.put("ramGb", ramGb)
            json.put("storageGb", storageGb)
            json.put("storageFreeGb", storageFreeGb)
            return json.toString()
        }

        @JavascriptInterface
        fun isPackageInstalled(pkg: String): Boolean {
            return try {
                packageManager.getPackageInfo(pkg, 0)
                true
            } catch (e: PackageManager.NameNotFoundException) {
                false
            }
        }

        // Mantém a tela ligada durante a partida — não exige nenhuma permissão,
        // é só uma flag da própria janela do app.
        @JavascriptInterface
        fun setKeepScreenOn(on: Boolean) {
            runOnUiThread {
                if (on) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }
        }

        // "Não perturbe" de verdade exige que o usuário libere manualmente o "Acesso a
        // notificações" nas Configurações do Android — nenhum app consegue ligar isso
        // sozinho, é uma proteção do próprio sistema.
        @JavascriptInterface
        fun isDndAccessGranted(): Boolean {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            return nm.isNotificationPolicyAccessGranted
        }

        @JavascriptInterface
        fun requestDndAccess() {
            runOnUiThread {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
            }
        }

        @JavascriptInterface
        fun setDnd(on: Boolean): Boolean {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            if (!nm.isNotificationPolicyAccessGranted) return false
            nm.setInterruptionFilter(
                if (on) NotificationManager.INTERRUPTION_FILTER_PRIORITY
                else NotificationManager.INTERRUPTION_FILTER_ALL
            )
            return true
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        webView = WebView(this)
        setContentView(webView)

        // Habilita tela cheia imersiva (esconde barra de status/navegação)
        hideSystemBars()

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true        // necessário para localStorage usado no app
            allowFileAccess = true
            useWideViewPort = true
            loadWithOverviewMode = true
        }
        webView.addJavascriptInterface(WebAppInterface(), "AndroidBridge")
        webView.webViewClient = WebViewClient() // mantém navegação dentro do próprio app
        webView.loadUrl("file:///android_asset/index.html")
    }

    private fun hideSystemBars() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.insetsController?.hide(android.view.WindowInsets.Type.systemBars())
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_FULLSCREEN
            )
        }
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}
