# Privacidade — Game Booster

Este app não tem nenhuma rede de anúncios, nenhum SDK de analytics/telemetria
e nenhum rastreador de terceiros. É código aberto (licença MIT, veja LICENSE)
— qualquer pessoa pode ler o código-fonte completo e confirmar isso.

## O que o app faz localmente (nada sai do aparelho)
- Lê specs do hardware (`Build`, `ActivityManager`, `StatFs`) só para mostrar na tela.
- Verifica se pacotes de jogos específicos estão instalados (`PackageManager`),
  só para exibir o jogo na lista — nenhuma dessas informações é enviada a lugar nenhum.
- Preferências de tema/sensibilidade ficam só em memória local do WebView.

## Por que não pedimos a permissão de internet
O `AndroidManifest.xml` não declara `android.permission.INTERNET`. Isso significa
que o app fisicamente não consegue fazer nenhuma chamada de rede, mesmo que
alguém tentasse adicionar isso no futuro sem querer. O único efeito colateral:
as fontes do Google (`fonts.googleapis.com`) linkadas no HTML não carregam —
o app cai automaticamente para a fonte padrão do sistema, sem quebrar nada.

Se algum dia quiser adicionar internet (ex: para checar atualizações), isso
precisaria ser uma escolha explícita e documentada aqui.
