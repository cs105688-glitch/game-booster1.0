# Game Booster — projeto Android (WebView)

Este projeto embrulha o app `game-booster.html` num WebView Android, pronto para gerar um `.apk`. Não preciso de internet nem servidor: o HTML fica dentro do próprio APK, em `app/src/main/assets/index.html`.

## Como gerar o APK

1. Instale o **Android Studio** (gratuito): https://developer.android.com/studio
2. Abra o Android Studio → **Open** → selecione a pasta `GameBooster-Android` (a que contém este arquivo).
3. Deixe o Gradle sincronizar (primeira vez demora alguns minutos, baixa dependências).
4. No menu superior: **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Quando terminar, clique em **locate** no aviso — o arquivo fica em:
   `app/build/outputs/apk/debug/app-debug.apk`
6. Copie esse `.apk` para o celular (cabo, Drive, etc.) e instale — é preciso permitir "fontes desconhecidas" no Android.

Esse é um APK de debug, ótimo para testar no seu A05s. Para publicar na Play Store depois, é preciso gerar uma versão **assinada** (Build → Generate Signed Bundle/APK) — o próprio Android Studio guia esse passo.

## Alternativa sem instalar nada (mais rápido, menos controle)
Se preferir não mexer no Android Studio, dá pra gerar o APK direto do HTML em serviços como **PWABuilder** (pwabuilder.com) ou **Median.co**: você sobe o `index.html` (ou hospeda e cola a URL) e eles empacotam o APK prontos para baixar. Fica mais rápido, mas com menos controle sobre nome, ícone e permissões do que este projeto.

## O que já está pronto
- Tela cheia imersiva (some com barra de status/navegação, ideal para jogo)
- JavaScript e armazenamento local habilitados (o app usa isso internamente)
- Botão voltar do Android integrado à navegação do app
- Nome do app: "Game Booster" — pacote: `com.charles.gamebooster`

## Personalizar
- **Ícone**: troque `android:icon` no `AndroidManifest.xml` por um ícone seu (Android Studio tem um gerador em Image Asset Studio).
- **Nome do pacote**: mude `com.charles.gamebooster` no `build.gradle` e na pasta de pacotes.
- **Atualizar o app**: edite `app/src/main/assets/index.html` e gere o APK de novo.
